package Registration;
import java.util.Arrays;

class Student {
	private String id;
	private String name;
	
	public Student(String id, String name) {
		this.name = name;
		this.id = id;
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}
	
}

class Course {
	String coursename;
	
	int numberOfStudent;
	Student[] registeredStudent;
	
	public Course (String coursename, int numberOfStudent) {
		this.coursename = coursename;
		this.numberOfStudent = numberOfStudent;
	}
	
	public Student[] getStudent() {	
		return registeredStudent;	
	}
	
	public boolean isFull() {

		if (!(numberOfStudent<10)) {
			return true;
		}else {
			return false;
		}	
	}
	
	public String getCoursename() {
		return coursename;
	}

	public int getNumberOfStudent() {
		return numberOfStudent;
	}
	
	public boolean registerStudent(Student student) {
		
		if (!isFull()) {
			System.out.println("Student: " + student.getName() + " have been registed in the class now.");
			return true;
		}else {
			System.out.println("The class is full, please choose another one!");
			return false;
		}
	}
		
}

public class School {

	public void main(String[] args) {
	
	}
}


