package transport;

public class Car {

	String carname;
	double costcaspermile = 5; 
	
	
	public Car(String carname) {
		this.carname = carname;
	}
	public void carStart() {
	
		System.out.println("Car “" + "”" + " is started!");
	}

	public void carStop() {
		System.out.println("Car “" + "”" + " is Stopped!");
	}
	
}
