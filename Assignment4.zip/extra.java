package EXTRA;

import java.util.Arrays;

public class app {

/*Given an array containing m distinct numbers taken from 0, 1, 2 …, n, find the one that is missing from the array. 
 * For example, given nums = {0, 1, 3}, return 2.*/


	public static void missingNumber(int[] nums) {
              
        for (int i = 0; i < nums.length; i++) {
        	
        	//for this case, since only one missing, so we only need check the first case happened.
        	//if we have more missing, then we need loop all and also check the gap between two missing case happened.
        	if(nums[i] != i) {
        		
        		System.out.println("The missing one is " + i);
        		break;
        	}
        }
        return;
       
	}

/*Given an array nums, write a function to move all 0's to the end of it while maintaining the relative order of the non-zero elements. 
 * For example, given nums = {0, 1, 0, 3, 12}, after calling your function, nums should be {1, 3, 12, 0, 0}, 
 * You must do this in-place without making a copy of the array.*/


	public static void moveZeroes(int[] nums) {
	
	//First, check if unms[i] = 0, and move to the last
	//Second, setup isAll0ontheright, to define a time to stop.
	int temp;
	int z = 0;
	int v = 0;
	while (v<nums.length) {
		for (int i = 0; i < nums.length; i++) {
			
		 		while(nums[i] == 0) {
						int check = 0;
						for (int x = i; x< nums.length-1; x++) {
							//System.out.println(nums[x]);
							check = nums[x] + check;
						}	
						if (check!=0) {
						
							temp = nums[nums.length-1-z];
								if(nums[0]==0) {
									for (int y = 0; y < nums.length-1-z;y++) {
										nums[y] = nums[y+1];
										System.out.println(nums[y]);
									} 
							
								}else {
									for (int y = 1; y < nums.length-2-z;y++) {
										nums[y] = nums[y+1];
										//System.out.println(nums[y]);
									}	
								}
							nums[nums.length-1-z] = 0;	
						z++;
			
						}
				//break;		
				}
			//break;	
			}
		v++;	
		}	
		System.out.println(Arrays.toString(nums));	
	}
	public static void main(String[] args) {
		
		int[] nums = {0,0,3,0,5,6,7};
		
		//missingNumber(nums);
		moveZeroes(nums);
	}

}
