package transport;

public class GasTank {

	double amount = 0;
	
	public double addGas(double addgas) {	
		amount = addgas + amount;
	return amount;
	}

	public double useGas(double usegas) {
		amount = amount - usegas;
	return amount;	
	}
	
	public double getGasLevel () {
	return amount;
	}
	
}
