package bookstore;


class Book {	
	private String title;
	
	private float[] price;
	
	public Book(float[] price) {
		this.price = price;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public float[] getPrice() {
		return price;
	}
	public void setPrice(float[] price) {
		this.price = price;
	}
}

class Customer	{
	private String name ;

	private int[] num;
	
	public Customer(String name, int[] num) {
		this.name = name;
		this.num = num;
	}	
		
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int[] getNum() {
		return num;
	}

	public void setNum(int[] num) {
		this.num = num;
	}
	
	
    
}
public class bookstore {

	
}
