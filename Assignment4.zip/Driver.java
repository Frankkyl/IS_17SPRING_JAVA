package transport;

public class Driver {
	String drivername;
	
	double hours;
	
	public void drivecar() {
		System.out.println(drivername + " is start drivering!");
	}
	
}

