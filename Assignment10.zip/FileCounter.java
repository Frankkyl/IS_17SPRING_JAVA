/**
 * Created by kysft on 4/8/17.
 */
/**
 A class to count the number of characters, words, and lines in files.
 */
import java.util.*;

public class FileCounter
{
    int wordCount=0;
    int lineCount=0;
    int charCount=0;
    /**
     Constructs a FileCounter object.
     */
    public FileCounter()
    {
       this.wordCount=wordCount;
       this.lineCount=lineCount;
       this.charCount=charCount;
    }

    /**
     Processes an input source and adds its character, word, and line
     counts to this counter.
     @param in the scanner to process
     */
    public void read(Scanner in)
    {
        //test path:/Users/kysft/Desktop/demo1.java

        while(in.hasNextLine()){
            HashMap<Integer, String> hm=new HashMap();
            int key=0;
            String newStr = in.nextLine();
            String[] newWord=newStr.split(" ");
            for(int i=0;i<newWord.length;i++){
                for(int j=0;j<newWord[i].length();j++){
                    newWord[i]=newWord[i].replaceAll("[\\pP‘’“”]", "");
                }
                if(!newWord[i].equals("")){
                    hm.put(key,newWord[i]);
                    key++;
                }
            }
            for(int i=0;i<hm.size();i++){
                for(int j=0;j<hm.get(i).length();j++){
                    charCount++;
                }
            }
            //charCount=charCount+newStr.length();//included the "blank"
            wordCount=wordCount+hm.size();
            lineCount++;
        }
    }

    /**
     Gets the number of words in this counter.
     @return the number of words
     */
    public int getWordCount()
    {
        return wordCount;
    }

    /**
     Gets the number of lines in this counter.
     @return the number of lines
     */
    public int getLineCount()
    {
        return lineCount;
    }

    /**
     Gets the number of characters in this counter.
     @return the number of characters
     */
    public int getCharacterCount()
    {
        return charCount;
    }

}
