import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/**
 * Created by kysft on 4/8/17.
 */

/*Write a program that is called TwoNumbersCalculator.
After running the program, the user will first type in two numbers(Integer or Double)
and then choose one operator from “+”, “-“, “*”, “/”.
After clicking on the button of “calculate”, the result will be shown on the screen.
For example, the user type in “5” and “6” and choose “*”.
Then, click the button of “calculate” and the result of 30 will be on the screen.*/

public class TwoNumbersCalculator extends JFrame implements ActionListener{
    JButton jbc;
    JRadioButton jrb1,jrb2,jrb3,jrb4;
    JTextField jtf1,jtf2,jtf3;
    JPanel jp1,jp2,jp21,jp22,jp3;
    JLabel jl1,jl11,jl12,jl2,jl3,jl4;

    public TwoNumbersCalculator() {
        //define first;
        jbc = new JButton("Calculate");
        //jbc.setActionCommand("cal");

        jl1=new JLabel("Type your No. here!");
        jl11=new JLabel("Number I");
        jl12=new JLabel("Number II");
        jl2=new JLabel("Chose the operator.");
        jl3=new JLabel("Click the BUTTON below!");
        jl4=new JLabel("Here we GO!");

        jrb1 = new JRadioButton("+");
        //jrb1.setActionCommand("+");
        jrb2 =new JRadioButton("-");
        //jrb2.setActionCommand("-");
        jrb3 =new JRadioButton("*");
        //jrb3.setActionCommand("*");
        jrb4 =new JRadioButton("/");
        //jrb4.setActionCommand("/");
        ButtonGroup bg=new ButtonGroup();
        bg.add(jrb1);
        bg.add(jrb2);
        bg.add(jrb3);
        bg.add(jrb4);

        jtf1=new JTextField();
        jtf2=new JTextField();
        jtf3=new JTextField();

        jp1=new JPanel();
        jp2=new JPanel();
        jp21=new JPanel();
        jp22=new JPanel();
        jp3=new JPanel();

        //add to component
        this.add(jp1,BorderLayout.NORTH);
        this.add(jp2,BorderLayout.CENTER);
        this.add(jp3,BorderLayout.SOUTH);
        /*this.setLayout(new GridLayout(20,1,2,2));//not work...figure out later..
        this.add(jp1);
        this.add(jp2);
        this.add(jp3);*/
        //P1
        jp1.setLayout(new GridLayout(5,1,10,10));
        jp1.add(jl1);
        jp1.add(jl11);
        jp1.add(jtf1);
        jp1.add(jl12);
        jp1.add(jtf2);
        //P2
        jp2.add(jp21);
        jp2.add(jp22);
        jp21.add(jl2);
        jp22.setLayout(new GridLayout(1,5,10,10));
        jp22.add(jrb1);
        jp22.add(jrb2);
        jp22.add(jrb3);
        jp22.add(jrb4);
        //P3
        jp3.setLayout(new GridLayout(5,1,5,5));
        jp3.add(jl3);
        jp3.add(jbc);
        jp3.add(jl4);
        jp3.add(jtf3);

        //for screen update
        this.setTitle("Frank's first Calculator");
        this.setSize(300, 500);
        this.setLocation(200, 100);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jbc.addActionListener(this::actionPerformed);
    }

    public String newCalculator() {
        double rlt=0;
        Double n1=Double.parseDouble(jtf1.getText());
        Double n2=Double.parseDouble(jtf2.getText());
        rlt=checkOperator(n1,n2);
        return Double.toString(rlt);
    }
    public double checkOperator(Double n1, Double n2){
        double cop=0;
        if(jrb1.isSelected()){
            cop=n1+n2;
        }else if(jrb2.isSelected()){
            cop=n1-n2;
        }else if(jrb3.isSelected()) {
            cop = n1 * n2;
        }else{
            cop =n1/n2; //since they all double, so after /, it would be no an int
        }
        return cop;
    }

    public static void main(String[] args) {
        TwoNumbersCalculator tnc = new TwoNumbersCalculator();
        //tnc.newCalculator();

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        jtf3.setText(newCalculator());
    }
}
