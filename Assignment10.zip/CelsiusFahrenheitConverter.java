import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by kysft on 4/8/17.
 */

/*Write a program that is called CelsiusFahrenheitConverter.
After running this program, the user will first type in a number with either Celsius or Fahrenheit.
Then, the user will click a button called “convert”.
Finally, there will be a result in another temperature unit showing on the screen.
For example, the user type in 70 Celsius and he will get the result of 158 Fahrenheit.*/

public class CelsiusFahrenheitConverter extends JFrame implements ActionListener{

    JButton jbt;
    JRadioButton jrbf,jrbc;
    JTextField jtf1,jtf3;
    JPanel jp1,jp2,jp21,jp22,jp3;
    JLabel jl1,jl11,jl2,jl3,jl4;

    public CelsiusFahrenheitConverter(){
        //define first;
        jbt = new JButton("Translate");
        //jbc.setActionCommand("cal");

        jl1=new JLabel("Type the degree below!");
        jl11=new JLabel("Degree:");
        jl2=new JLabel("It's 'Celsius' or 'Fahrenheit' ?");
        jl3=new JLabel("Click the BUTTON below!");
        jl4=new JLabel("Here we GO! The degree after transfer is: ");

        jrbf = new JRadioButton("Fahrenheit");
        //jrb1.setActionCommand("+");
        jrbc =new JRadioButton("Celsius");
        //jrb2.setActionCommand("-");

        ButtonGroup bg=new ButtonGroup();
        bg.add(jrbf);
        bg.add(jrbc);

        jtf1=new JTextField();
        jtf3=new JTextField();

        jp1=new JPanel();
        jp2=new JPanel();
        jp21=new JPanel();
        jp22=new JPanel();
        jp3=new JPanel();

        //add to component
        this.add(jp1,BorderLayout.NORTH);
        this.add(jp2,BorderLayout.CENTER);
        this.add(jp3,BorderLayout.SOUTH);

        //P1
        jp1.setLayout(new GridLayout(5,1,10,10));
        jp1.add(jl1);
        jp1.add(jl11);
        jp1.add(jtf1);

        //P2
        jp2.add(jp21);
        jp2.add(jp22);
        jp21.add(jl2);
        jp22.setLayout(new GridLayout(1,5,10,10));
        jp22.add(jrbf);
        jp22.add(jrbc);
        //P3
        jp3.setLayout(new GridLayout(5,1,5,5));
        jp3.add(jl3);
        jp3.add(jbt);
        jp3.add(jl4);
        jp3.add(jtf3);

        //for screen update
        this.setTitle("Frank's first Translator");
        this.setSize(300, 500);
        this.setLocation(200, 100);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jbt.addActionListener(this::actionPerformed);
    }

    public String transferBetweenFC(){
        int degree=Integer.parseInt(jtf1.getText());
        int newDegree;

        if(jrbf.isSelected()){
            newDegree=(degree-32)*5/9;
            //System.out.println("Your input is Fahrenheit, now we transfer it to Celsius!");
            //System.out.println("The " + degree + " of Fahrenheit is equals " + newDegree + " Celsius!");
        }else{
            newDegree=degree*9/5+32;
            //System.out.println("Your input is Celsius, now we transfer it to Fahrenheit!");
            //System.out.println("The " + degree + " of Celsius is equals " + newDegree + " Fahrenheit!");
        }
        return Integer.toString(newDegree);
    }
    public static void main(String[] args) throws Exception{
        CelsiusFahrenheitConverter cfc= new CelsiusFahrenheitConverter();

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        jtf3.setText(transferBetweenFC());
    }
}
