/**
 * Created by kysft on 2/19/17.
 */

import java.util.*;

public class Extra5 {

    /*Given two sorted integer arrays nums1 and nums2, merge nums2 into nums1 
    as one ascending sorted array.You may assume that nums1 has enough space
    (size that is greater or equal to m + n)to hold additional elements from nums2.
    The number of elements initialized in nums1 and nums2 are m and n respectively.*/

    public void merge(int[] nums1, int m, int[] nums2, int n) {
        //write your code here
        //FL's code:
        int[] newarray = new int[m + n];
        int temp = 0;

        while (n == 0) {
            newarray = nums1;
        }
        while (n != 0) {

            for (int i = 0; i < m; i++) {
                newarray[i] = nums1[i];
            }
            for (int i = m; i < m + n; i++) {
                newarray[i] = nums2[i - m];
            }
        }
        for (int j = 0; j < m + n; j++) {
            if (newarray[j] > newarray[j + 1]) {
                temp = newarray[j + 1];
                newarray[j + 1] = newarray[j];
                newarray[j] = temp;
            }
        }
        System.out.println(newarray);
    }

    /*Given a matrix of m x n elements (m rows, n columns), return all elements of the matrix in spiral order.
    For example,
    Given the following matrix:
        {{1,2,3},
        {4,5,6},
        {7,8,9}}
    You should return {1,2,3,6,9,8,7,4,5}.*/

    public List<Integer> spiralOrder(int[][] matrix) {
        //write your code here
        //FL's code;
        int row = matrix.length;
        int col = matrix[0].length;
        int newarr[]=new int[];

        for (int i=0;i<=col-1;i++) {
            newarr[i]=matrix[0][i];


//            while(result.size()<m*n){
//                for(int j=left; j<=right; j++){
//                    result.add(matrix[top][j]);
//                }
//                top++;//???why?
        }

        /*for (int i=0;i<matrix[0].length;i++ ) {
            int[] a1 = new int[matrix[0].length];
            a1[i] = matrix[0][i];
        }

        for (int x=matrix[0].length-1;x>0;x-- ) {
            int[] a3 = new int[matrix[0].length];
            a3[x] = matrix[0][x];
        }

        for (int j=1;j<matrix.length;j++) {
            int[] a2 = new int[matrix.length-1];
            a2[j] = matrix[j][matrix[0].length-1];
        }

        for (int y=1;y<matrix.length-1;y--) {
            int[] a4 = new int[matrix.length-2];
            a4[y] = matrix[y][0];
        }*/


//        public static void main(String[] args){
//
//            int nums1[] = {1, 3, 4, 5, 12};
//            int nums2[] = {7, 8, 9, 16};
//
//            Extra5 ex = new Extra5();
//            ex.merge(nums1, 5, nums2, 4);
//        }

    }

}
