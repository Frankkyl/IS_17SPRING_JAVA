/**
 * Created by kysft on 2/18/17.
 */
public class Candy extends DessertItem {

    private double weightCD;
    private int costCD;
    //.89 /lbw
    private double priceCD;

    public int getCost(){
        costCD = (int)Math.round((weightCD*priceCD));
        return costCD;
    }
    public Candy (String name, double price, double cost){
    }


}
