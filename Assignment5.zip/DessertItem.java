/**
 * Created by kysft on 2/18/17.
 */
public abstract class DessertItem {

    public String getName() {
        return name;
    }
    /*public void setName(String name) {
        this.name = name;
    }*/
    public abstract int getCost();
    //FL:result is cents
    public DessertItem (String name){
        this.name=name;
    }
    String name;
    public DessertItem (String name, double print, double cost){
    }
}
