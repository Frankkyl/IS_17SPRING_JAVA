/**
 * Created by kysft on 2/18/17.
 */
public class Sundae extends IceCream {
    public Sundae (String name, int cost) {
    }
}
