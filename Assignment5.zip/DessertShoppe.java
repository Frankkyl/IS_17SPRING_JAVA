/**
 * Created by kysft on 2/18/17.
 */
public class DessertShoppe {

    final double taxrate = 0.2;
    protected String nameOfstore;
    int maxOfitems = 200;

    Candy cd = new Candy();
    Cookie ck = new Cookie();


    public String cents2dollarsAndCents(int payment){
        String totalCost;

        //if ()

        totalCost = Integer.toString(payment);
        return totalCost;
    }
    public boolean checkMaxItems() {
        if (maxOfitems > 200) {
            return false;
        } else {
            return true;
        }
    }
}
