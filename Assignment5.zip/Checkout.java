/**
 * Created by kysft on 2/18/17.
 */
public class Checkout {

    double amount;


    public int numberOfItems() {
        return amount;
    }
}
