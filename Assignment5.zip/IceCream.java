/**
 * Created by kysft on 2/18/17.
 */
public class IceCream extends DessertItem {

    int costIC;
    int number;

    public int getCost() {

        return costIC;

    }
    public IceCream (String name, int cost) {
    }
}
