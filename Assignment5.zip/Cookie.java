/**
 * Created by kysft on 2/18/17.
 */
public class Cookie extends DessertItem {

    double weightCK;
    int costCK;
    final double priceCK = 99.75;
    public int getCost(){
        costCK = (int)(weightCK*priceCK);
        return costCK;
    }
    public Cookie (String name, double price, double cost);
}
