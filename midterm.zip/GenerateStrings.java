/**
 * Created by kysft on 3/18/17.
 */

import java.util.ArrayList;

public class GenerateStrings {

    public static String gengerateStrings(String s1, String s2) {
        String str = "";
        ArrayList<String> al = new ArrayList<String>();
        for (int i = 0; i < s1.length(); i++) {
            for (int j = 0; j < s2.length(); j++) {
                str = s1.substring(i, i + 1) + s2.substring(j, j + 1);
                al.add(str);
            }
        }
        //System.out.println(al);

        for (int m = 0; m < al.size(); m++) {
            for (int n = m + 1; n < al.size(); n++) {
                //String a = al.get(m);
                //String b = al.get(n);
                if (al.get(m).equals(al.get(n))) {
                    al.remove(n);
                    //System.out.println(al);
                    n--;//make sure no missing during the loop
                }
            }
        }
        return al.toString();
    }

    public static void main(String[] args) {
        GenerateStrings GS1 = new GenerateStrings();
        String s1 = "ABCD";
        String s2 = "EFGH";
        System.out.println(GS1.gengerateStrings(s1, s2));
        System.out.println();
        String s3 = "ACDC";
        String s4 = "ABBA";
        System.out.println(GS1.gengerateStrings(s3, s4));
    }
}
