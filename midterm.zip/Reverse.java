/**
 * Created by kysft on 3/17/17.
 */

import java.util.ArrayList;

public class Reverse {

    //class E{
    //}
    public static void reverse(ArrayList<Integer> list) {
        for (int i = 1; i < list.size(); i++) {//keep the first one, it would be the last one when the loop end
            //System.out.println(list);
            //int x = list.remove(i);// should no this during the debug, since it change the varient
            list.add(0, list.remove(i));//add the the first
            //System.out.println(list);
        }
    }

    public static void main(String[] args) {
        ArrayList<Integer> al = new ArrayList<Integer>();
        al.add(1);
        al.add(3);
        al.add(9);
        System.out.println(al);
        Reverse re = new Reverse();
        reverse(al);
        System.out.println(al);
    }
}
