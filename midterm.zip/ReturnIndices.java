/**
 * Created by kysft on 3/18/17.
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Arrays;

public class ReturnIndices {
    public int[] twoSum(int[] nums, int target) {
        int[] indices = {0, 0};
        for (int i = 0; i < nums.length; i++) {
            for (int j = i + 1; j < nums.length; j++) {
                if (nums[i] + nums[j] == target) {
                    indices[0] = i;
                    indices[1] = j;
                }
            }
        }
        return indices;
    }
    //Q:Why this hm.get(9) out put as [2,3]?
    /*public int[] twoSum2(int[] nums, int target) {
        HashMap<Integer, int[]> hm = new HashMap<Integer, int[]>();
        int[] indices = {0, 0};
        for (int i = 0; i < nums.length; i++) {
            for (int j = i + 1; j < nums.length; j++) {
                indices[0] = i;
                indices[1] = j;
                hm.put(nums[i] + nums[j], indices);
                System.out.print(nums[i] + nums[j] + " ");
                System.out.println(Arrays.toString(hm.get(nums[i] + nums[j])));
            }
        }
        System.out.println(hm);
        System.out.println(target);
        System.out.println(Arrays.toString(hm.get(9)));
        return hm.get(target);

    }*/

    public static void main(String[] args) {
        ReturnIndices ri = new ReturnIndices();
        int nums[] = {2, 7, 11, 15};
        int target = 9;
        System.out.println(Arrays.toString(ri.twoSum(nums, target)));//Arrays.toString()
        //System.out.println(Arrays.toString(ri.twoSum2(nums, target)));
    }
}
