/**
 * Created by kysft on 3/18/17.
 */

public class SingleNumber {
    public static int singleNumber(int[] nums) {
        int num = 0;
        for (int i = 0; i < nums.length; i++) {
            for (int j = i + 1; j < nums.length; j++) {
                if (nums[i] != nums[j]) {
                    num = nums[i];
                }
            }
        }
        return num;
    }

    public static void main(String[] args) {
        SingleNumber sn = new SingleNumber();
        int[] array1 = {2, 2, 5, 4, 5, 6, 4};
        System.out.println(sn.singleNumber(array1));
        int[] array2 = {2, 2, 5, 4, 5, 6, 6, 8, 4};
        System.out.println(sn.singleNumber(array2));
    }
}
