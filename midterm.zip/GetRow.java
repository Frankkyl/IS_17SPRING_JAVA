/**
 * Created by kysft on 3/18/17.
 */

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.lang.Integer;

public class GetRow {
    public List<Integer> getRow(int rowIndex) {
        List<List<Integer>> list = new ArrayList<List<Integer>>();//to have the obj change to another line
        List<Integer> alrow = new ArrayList<Integer>();
        for (int j = 0; j < rowIndex; j++) {
            alrow.add(j);
            for (int i = rowIndex; i > j; i--) {
                alrow.add(0);
            }
            int temp=1;
            for (int i = 0; i <= j; i++) {

                alrow.add(temp);
                temp=temp*(j-i)/(i+1);
            }
        }

        list.add(alrow);

        List<Integer> newlist =new ArrayList<Integer>();//list.get(rowIndex);
        newlist.add(list.get(rowIndex));
        return newlist;
    }

    public static void main(String[] args) {
        GetRow gr = new GetRow();
        System.out.println(gr.getRow(3));
    }
}
