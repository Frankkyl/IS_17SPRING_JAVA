import java.util.Calendar;

/**
 * Created by kysft on 3/1/17.
 */
public class Dog extends Pet implements Boardable{
    public String getSize() {
        return size;
    }

    private String size;
    public Dog(String name, String ownerName, String color, String size){
        super(name,ownerName,color);
        this.size = size;
    }
    public String toString(){
        String str = new String();
        return str = "DOG: /n" + super.toString() + " Size: " + getSize();
    }

    private Calendar startDate=Calendar.getInstance();
    private Calendar  endDate=Calendar.getInstance();

    public void setBoardStart(int month, int day, int year){
        startDate.set(month,day,year);
    }
    public void setBoardEnd(int month, int day, int year){
        endDate.set(month,day,year);
    }
    public boolean boarding(int month, int day, int year){
        Calendar bd = Calendar.getInstance();
        bd.set(year,month,day);
        if(bd.before(startDate)||bd.after(endDate)){
            return false;
        }else{
            return true;
        }
    }
}
