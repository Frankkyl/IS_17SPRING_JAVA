/**
 * Created by kysft on 3/1/17.
 */

import java.util.Calendar;

public class Cat extends Pet implements Boardable{
    private String hairLength;
    public Cat(String name, String ownerName, String color, String hairLength){
        super(name, ownerName, color);
        this.hairLength = hairLength;
    }
    public String getHairLength(){
        return hairLength;
    }
    public String toString(){
        String str = new String();
        return str = "CAT: " + "/n" + getPetName() + " owned by " + getOwnerName() + "/nColor: " + getColor() + "/nSex: " + getSex() + "/nHair: " + getHairLength();
        //return str = "CAT: " + "/n" + super.toString() + getHairLength();
    }

    private Calendar startDate=Calendar.getInstance();//Q: how I could know I should use this...
    private Calendar  endDate=Calendar.getInstance();

    public void setBoardStart(int month, int day, int year){
        startDate.set(month,day,year);
    }
    public void setBoardEnd(int month, int day, int year){
        endDate.set(month,day,year);
    }
    public boolean boarding(int month, int day, int year){
        Calendar bd = Calendar.getInstance();
        bd.set(year,month,day);
        if(bd.before(startDate)||bd.after(endDate)){
            return false;
        }else{
            return true;
        }
    }
}
