/**
 * Created by kysft on 3/1/17.
 */

import java.lang.String;

public class Pet {
    public String getPetName() {//Q: why getter method always go top line, who to cancel the auto fill of }
        return petName;
    }
    public String getOwnerName() {
        return ownerName;
    }
    public String getColor() {
        return color;
    }
    private String petName;
    private String ownerName;
    private String color;

    protected String sex;
    public static final int MALE = 0;
    public static final int FEMALE = 1;
    public static final int SPAYED =2;
    public static final int NEUTERED = 3;

    public Pet(String name, String ownerName, String color){
        this.petName = name;
        this.ownerName = ownerName;
        this.color = color;
    }

    public void setSex(int sexid){
        if(sexid == 0){
            sex = "MALE";
        }else if (sexid == 1){
            sex = "FEMALE";
        }else if (sexid == 2){
            sex = "SPAYED";
        }else if ( sexid == 3){
            sex = "NEUTERED";
        }else {
            System.out.println("Wrong Input! Pls choose the correct ID between '0 to 3'!");
        }
    }
    public String getSex(){
        return sex;
    }
    public String toString(){ //Q: why "toString", and no age mentioned in pet?
                              //Q: what's the blue icon and red arrow on the left in line #49?
        String str="";
        return str=getPetName() + "owned by " + getOwnerName() + "/nColor: " + getColor() + "/nSex: " + getSex();
    }
}
