/**
 * Created by kysft on 2/26/17.
 */

import java.util.*;

public class Mreview extends java.lang.Object implements Comparable<Mreview>{

    // instance variables
    private String title; //title of the the movie
    private ArrayList<Integer> ratings; //list of ratings stored in a store object
    // methods
    public Mreview(){
    }
    public Mreview(java.lang.String ttl){
        this.title = ttl;
    }
    public Mreview(java.lang.String ttl, int firstRating){
        this.title = ttl;
        this.ratings = new ArrayList();
        ratings.add(firstRating);
    }

    public String getTitle(){
       return title;
    }
    public void addRating(int r){
        ratings.add(r);
    }
    public double aveRating(){
        int sum = 0; //Q:why they set us it as double, cause the rate normally 1.2.3.4.5
        double ave = 0;
        for (int i = 0;i<ratings.size();i++ ) {
            sum = sum + ratings.get(i);
        }
        return ave = sum/ratings.size();
    }
    @Override
    public int compareTo(Mreview obj){ //need more check for interface comparable(T)
        return this.title.compareTo(obj.title);
    }

    @Override//Q:???
    public boolean equals(java.lang.Object obj){
        return this.title.equals(obj);
    }

    public java.lang.String toString(){
        String str = new String();
        str = title + ", average " + aveRating() + " out of ZZZ " + ratings;
    }
    public static void main(String[] args){

        //Q:Xixi's code is wrong? since she declar that the class as film name, which is part of class
        String t1 = "A";
        String t2 = "B";

        Mreview mr = new Mreview;
        mr.addRating(5);
        mr.addRating(8);

        System.out.println(t1 + "is a good film. /nIt's ave rate is " );
        System.out.println(mr.aveRating() + ".");
    }
}
