/**
 * Created by kysft on 3/1/17.
 */
public interface Boardable {

    public void setBoardStart(int month, int day, int year);
    public void setBoardEnd(int month, int day, int year);
    public boolean boarding(int month, int day, int year);
//Q: cant understand the code from Mia
//Q: where to code the requirments below:
//See the Cat and Dog classes for what these methods should do when implemented. Note, the month will be in the range 1-12, day in the range 1-31, and year will be a four digit number.
}
