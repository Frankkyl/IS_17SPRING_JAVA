
import java.lang.String;

/**
 * Created by kysft on 2/26/17.
 */
public class Account {
    protected String FirstName;
    protected String LastName;
    protected double CurBalance;

    public Account (String fname, String lname, double curblance) {// it's cb in website
        FirstName = fname;
        LastName = lname;
        CurBalance = curblance;
    }
    public String getAccType() {
        return this.getClass().getName();// Q: getClass() 哪来的？https://docs.oracle.com/javase/7/docs/api/java/lang/Class.html
    }
    public double DebitTransaction(double debitAmount){
        CurBalance = CurBalance - debitAmount;
        return CurBalance;
    }
    public double CreditTransaction(double creditAmount){
        CurBalance = CurBalance - creditAmount;
        return CurBalance;
    }
    public String toString(){
        return "Account name:" + FirstName + " " + LastName + ", Account Type: " + getAccType() + ", Balance: " + String.format("$%.2f", CurBalance);
    }

    public static void main(String[] args){
        Account ac1 = new Account("John","Smith",100);
        System.out.println(ac1);

        ac1.DebitTransaction(30.25); // should be $69.75
        System.out.println(ac1);

        ac1.CreditTransaction(10.10); // should be $79.85 //Q: why 10.10? missing 0.05
        System.out.println(ac1);
        /* Output of the unit test

        Account name: John Smith, Account Type: Account, Balance: $100.00
        Account name: John Smith, Account Type: Account, Balance: $69.75
        Account name: John Smith, Account Type: Account, Balance: $79.85
         */
    }
} // end class
